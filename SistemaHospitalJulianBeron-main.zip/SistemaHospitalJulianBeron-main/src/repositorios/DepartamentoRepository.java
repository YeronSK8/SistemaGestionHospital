package repositorios;

import entidades.Departamento;

public class DepartamentoRepository extends InMemoryRepository<Departamento> {}