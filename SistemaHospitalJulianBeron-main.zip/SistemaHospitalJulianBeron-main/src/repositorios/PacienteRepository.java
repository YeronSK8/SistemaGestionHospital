package repositorios;

import entidades.Paciente;

public class PacienteRepository extends InMemoryRepository<Paciente> {}
